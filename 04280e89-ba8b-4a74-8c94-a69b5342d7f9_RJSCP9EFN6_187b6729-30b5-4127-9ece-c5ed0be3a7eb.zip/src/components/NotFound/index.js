// Write your code here
import './index.css'

const NotFound = () => {
  ;<div className="notFound">
    <h1>Page Not Found!!</h1>
  </div>
}

export default NotFound
